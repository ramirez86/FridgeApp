sap.ui.define([
	"./utilities"
], function() {
	"use strict";

	// class providing static utility methods to retrieve entity default values.

	return {
		getDefaultValuesForAddItem: function() {
			return {
				"ID": "id-" + Date.now().toString(),
				"Name": "",
				"Brand": "",
				"Unit_Price": 0,
				"Currency": "",
				"Net_Qty": "",
				"Image": "",
				"List_Qty": 0,
				"Inventory_Qt": 0,
				"Ingredient_Qt": 0,
				"Location": "",
				"Exp_Date": null,
				"___FK_b77f4e305b39c65213cb9142_00080": "",
				"___FK_b77f4e305b39c65213cb9142_00084": "",
				"___FK_b77f4e305b39c65213cb9142_00094": ""
			};
		},
		getDefaultValuesForChangeItem: function() {
			return {
				"ID": "id-" + Date.now().toString(),
				"Name": "",
				"Brand": "",
				"Unit_Price": 0,
				"Currency": "",
				"Net_Qty": "",
				"Image": "",
				"List_Qty": 0,
				"Inventory_Qt": 0,
				"Ingredient_Qt": 0,
				"Location": "",
				"Exp_Date": null,
				"___FK_b77f4e305b39c65213cb9142_00080": "",
				"___FK_b77f4e305b39c65213cb9142_00084": "",
				"___FK_b77f4e305b39c65213cb9142_00094": ""
			};
		}
	};
});
